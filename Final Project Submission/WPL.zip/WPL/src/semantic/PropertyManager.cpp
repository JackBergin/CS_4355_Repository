/**
 * @file PropertyManager.cpp
 * @author Jack Bergin
 * @brief includes the header file that contains everything
 * @version 0.1
 * @date 2022-09-28
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "PropertyManager.h"