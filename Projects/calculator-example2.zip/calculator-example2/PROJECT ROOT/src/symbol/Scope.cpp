#include "Symbol.h"
#include "Scope.h"

Symbol* Scope::addSymbol(std::string id, SymType t) {
  Symbol* s = new Symbol(id, t);
  symbols.insert(std::pair(id, s));
  return s;
}

Symbol& Scope::addSymbol(Symbol& symbol) {
  symbols.insert(std::pair(symbol.identifier, &symbol));
  return symbol;
}

Symbol* Scope::findSymbol(std::string id) {
  Symbol* s;
  std::map<std::string, Symbol*>::const_iterator i = symbols.find(id);
  if (i == symbols.end()) {
    s = nullptr;
  } else {
    s = i->second;
  }
  return s;
}

std::string Scope::toString() const {
  std::ostringstream description;
  description << std::endl << "-------------------" << std::endl
    << "SCOPE: " << scopeId;
  if (parent != nullptr) {
    description << " PARENT: " << parent->scopeId;
  }
  description << std::endl << '{';
  for (auto sym : symbols) {
    description << std::endl << "    " << sym.second->toString();
  }
  description << std:: endl << '}' << std::endl << std::endl;

  return description.str(); 
}