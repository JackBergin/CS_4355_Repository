#include <catch2/catch_test_macros.hpp>
#include "SemanticVisitor.h"
#include <iostream>

TEST_CASE("Dummy semantic tests", "[semantic]") {
  CHECK(true == true);
}