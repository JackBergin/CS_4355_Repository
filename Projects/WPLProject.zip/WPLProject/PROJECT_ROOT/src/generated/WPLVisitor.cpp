
// Generated from WPL.g4 by ANTLR 4.10.1


#include "WPLVisitor.h"


