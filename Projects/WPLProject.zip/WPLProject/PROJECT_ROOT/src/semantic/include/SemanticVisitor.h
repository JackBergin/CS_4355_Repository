#pragma once
#include "antlr4-runtime.h"
#include "WPLBaseVisitor.h"
#include "STManager.h"
#include "PropertyManager.h"
#include "WPLErrorHandler.h"

class SemanticVisitor : WPLBaseVisitor {
  public :
    // Pass in the appropriate elements
    SemanticVisitor(STManager* stm, PropertyManager* pm) {
      stmgr = stm;
      bindings = pm;
    }
  
  std::any visitCompilationUnit(WPLParser::CompilationUnitContext *ctx) override;
  //std::any visitCuComponent(WPLParser::CuComponentContext *ctx);
  //std::any visitVarDeclaration(WPLParser::VarDeclarationContext *ctx);
  //std::any visitScalarDeclaration(WPLParser::ScalarDeclarationContext *ctx);
  //std::any visitScalar(WPLParser::ScalarContext *ctx);
  //std::any visitArrayDeclaration(WPLParser::ArrayDeclarationContext *ctx);
  //std::any visitType(WPLParser::TypeContext *ctx);
  //std::any visitVarInitializer(WPLParser::VarInitializerContext *ctx);
  //std::any visitExternDeclaration(WPLParser::ExternDeclarationContext *ctx);
  //std::any visitProcedure(WPLParser::ProcedureContext *ctx);
  //std::any visitProcHeader(WPLParser::ProcHeaderContext *ctx);
  //std::any visitExternProcHeader(WPLParser::ExternProcHeaderContext *ctx);
  //std::any visitFunction(WPLParser::FunctionContext *ctx);
  //std::any visitFuncHeader(WPLParser::FuncHeaderContext *ctx);
  //std::any visitExternFuncHeader(WPLParser::ExternFuncHeaderContext *ctx);
  //std::any visitParams(WPLParser::ParamsContext *ctx);
  //std::any visitBlock(WPLParser::BlockContext *ctx);
  //std::any visitStatement(WPLParser::StatementContext *ctx);
  //std::any visitLoop(WPLParser::LoopContext *ctx);
  //std::any visitConditional(WPLParser::ConditionalContext *ctx);
  //std::any visitSelect(WPLParser::SelectContext *ctx);
  //std::any visitSelectAlt(WPLParser::SelectAltContext *ctx);
  //std::any visitCall(WPLParser::CallContext *ctx);
  //std::any visitArguments(WPLParser::ArgumentsContext *ctx);
  //std::any visitArg(WPLParser::ArgContext *ctx);
  //std::any visitReturn(WPLParser::ReturnContext *ctx);
  //std::any visitConstant(WPLParser::ConstantContext *ctx);
  //std::any visitAssignment(WPLParser::AssignmentContext *ctx);
  //std::any visitArrayIndex(WPLParser::ArrayIndexContext *ctx);
  //std::any visitAndExpr(WPLParser::AndExprContext *ctx);
  //std::any visitIDExpr(WPLParser::IDExprContext *ctx);
  //std::any visitConstExpr(WPLParser::ConstExprContext *ctx);
  //std::any visitSubscriptExpr(WPLParser::SubscriptExprContext *ctx);
  //std::any visitRelExpr(WPLParser::RelExprContext *ctx);
  std::any visitAddExpr(WPLParser::AddExprContext *ctx);
  //std::any visitArrayLengthExpr(WPLParser::ArrayLengthExprContext *ctx);
  std::any visitUMinusExpr(WPLParser::UMinusExprContext *ctx);
  //std::any visitOrExpr(WPLParser::OrExprContext *ctx);
  std::any visitEqExpr(WPLParser::EqExprContext *ctx);
  std::any visitFuncProcCallExpr(WPLParser::FuncProcCallExprContext *ctx);
  //std::any visitNotExpr(WPLParser::NotExprContext *ctx);
  std::any visitParenExpr(WPLParser::ParenExprContext *ctx);
    
    std::string getErrors() { return errors.errorList(); }
    STManager* getSTManager() { return stmgr; }
    PropertyManager* getBindings() { return bindings; }
    bool hasErrors() { return errors.hasErrors(); }

  private: 
    STManager* stmgr;
    PropertyManager* bindings; 
    WPLErrorHandler errors;
};
