#include "SemanticVisitor.h"
#include <any>

/**
 * @brief Just visit the expressions below the program
 */
std::any SemanticVisitor::visitCompilationUnit (WPLParser::CompilationUnitContext *ctx) {
  stmgr->enterScope();    // initial scope (only one for this example)
  for (auto e : ctx->exprs) {
    e->accept(this);
  }
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitCuComponent(WPLParser::CuComponentContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitVarDeclaration(WPLParser::VarDeclarationContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitScalarDeclaration(WPLParser::ScalarDeclarationContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitScalar(WPLParser::ScalarContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitArrayDeclaration(WPLParser::ArrayDeclarationContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitType(WPLParser::TypeContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitVarInitializer(WPLParser::VarInitializerContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitExternDeclaration(WPLParser::ExternDeclarationContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitProcedure(WPLParser::ProcedureContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitProcHeader(WPLParser::ProcHeaderContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitExternProcHeader(WPLParser::ExternProcHeaderContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitFunction(WPLParser::FunctionContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitFuncHeader(WPLParser::FuncHeaderContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitExternFuncHeader(WPLParser::ExternFuncHeaderContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitParams(WPLParser::ParamsContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitBlock(WPLParser::BlockContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitStatement(WPLParser::StatementContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitLoop(WPLParser::LoopContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitConditional(WPLParser::ConditionalContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitSelect(WPLParser::SelectContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitSelectAlt(WPLParser::SelectAltContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitCall(WPLParser::CallContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitArguments(WPLParser::ArgumentsContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitArg(WPLParser::ArgContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitReturn(WPLParser::ReturnContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief constant.type == whichever declar. was used
 * @return SymType::BOOLEAN if bool. SymType::INTEGER if int. SymType::STRING if str. SymType::UNDEFINED if error.
 */
std::any SemanticVisitor::visitConstant(WPLParser::ConstantContext *ctx) {
  SymType type = SymType::UNDEFINED;
  if (ctx->BOOLEAN()){
    type = SymType::BOOL;
  }
  else if (ctx->INTEGER()){
    type = SymType::INT;
  }
  else if (ctx->STRING()){
    type = SymType::STR;
  }
  return type;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitAssignment(WPLParser::AssignmentContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitArrayIndex(WPLParser::ArrayIndexContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitAndExpr(WPLParser::AndExprContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief  id.type = str
 * @return SymType::STRING if id != nullptr. SymType::UNDEFINED if there is an error. 
 */
std::any SemanticVisitor::visitIDExpr(WPLParser::IDExprContext *ctx) {
  std::string id = ctx->ID()->getText();
  Symbol *symbol = stmgr->findSymbol(id);
  SymType type = SymType::UNDEFINED;
  if(symbol == nullptr){
    errors.addSemanticError(ctx->getStart(), id + " is undeclared.");
   } else{
    type = symbol->type
   }
   return type;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitConstExpr(WPLParser::ConstExprContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitSubscriptExpr(WPLParser::SubscriptExprContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitRelExpr(WPLParser::RelExprContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief AddExpr.type = SymType::INT && left.type == right.type
 * 
 * @return SymType::INT if there are no errors or SymType::UNDEFINED if there are errors.
 */
std::any SemanticVisitor::visitMultExpr(WPLParser::MultExprContext *ctx){
  SymType result = std::any_cast<SymType>(ctx -> right ->accept(this));
  SymType left = std::any_cast<SymType>(ctx -> left ->accept(this));
  if ((result != SymType::INT) || (left != SymType::INT) ) {
    errors.addSemanticError("Both sides of the '+' must have type INT. A type " + Symbol::getSymTypeName(result) + " cannot be multiplied with " +Symbol::getSymTypeName(left) + ".";
    result = SymType::UNDEFINED;
  }
  return result;
}

/**
 * @brief AddExpr.type = SymType::INT && left.type == right.type
 * 
 * @return SymType::INT if there are no errors or SymType::UNDEFINED if there are errors.
 */
std::any SemanticVisitor::visitAddExpr(WPLParser::AddExprContext *ctx){
  SymType result = std::any_cast<SymType>(ctx -> right ->accept(this));
  SymType left = std::any_cast<SymType>(ctx -> left ->accept(this));
  if ((result != SymType::INT) || (left != SymType::INT) ) {
    errors.addSemanticError("Both sides of the '+' must have type INT. A type " + Symbol::getSymTypeName(result) + " cannot be multiplied with " +Symbol::getSymTypeName(left) + ".";
    result = SymType::UNDEFINED;
  }
  return result;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitArrayLengthExpr(WPLParser::ArrayLengthExprContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief UnaryMinusExpr.type = ex.type && ex.type == INT;
 * @return SymTyp::INT if no error, SymType::UNDEFINED if an error.
 */
std::any SemanticVisitor::visitUMinusExpr(WPLParser::UMinusExprContext *ctx) {
  auto t = std::any_cast<SymType>(ctx -> ex ->accept(this));
  if (t != SymType::INT){ // Type mismatch
    errors.addSemanticError(ctx->getStart(), "INT expression expected, but was different.");
    t = SymType::UNDEFINED;
  }
  return t;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitOrExpr(WPLParser::OrExprContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief EQExpr.type = SymType::BOOL && left.type == right.type
 * 
 * @return SymType::BOOL if there are no errors or SymType::UNDEFINED if there are errors.
 */
std::any SemanticVisitor::visitEqExpr(WPLParser::EqExprContext *ctx) {
  SymType result = SymType::BOOL;
  result = std::any_cast<SymType>(ctx -> right ->accept(this));
  auto left = std::any_cast<SymType>(ctx -> left ->accept(this));
  if (result != left) {
    errors.addSemanticError(ctx->getStart(), "Both sides of '=' must have the same type");
    result = SymType::UNDEFINED;
  }
  return result;
}

/**
 * @brief Done, need to test
 * @return SymType != nullptr (id) if successful. SymType::UNDEFINED if there is an error. 
 */
std::any SemanticVisitor::visitFuncProcCallExpr(WPLParser::FuncProcCallExprContext *ctx) {
   std::string id = ctx->fpname->getText();
   Symbol *symbol = stmgr->findSymbol(id);
   SymType type = SymType::UNDEFINED;
   if(symbol == nullptr){
    errors.addSemanticError(ctx->getStart(), id + " is undeclared");
   } else{
    type = symbol->type
   }
   return type;
}

/**
 * @brief **** Still working on ****
 * @return SymType::UNDEFINED.
 */
std::any SemanticVisitor::visitNotExpr(WPLParser::NotExprContext *ctx) {
  return SymType::UNDEFINED;
}

/**
 * @brief ParenExpr.type = ex.type
 */
  std::any SemanticVisitor::visitParenExpr(WPLParser::ParenExprContext *ctx){
    return ctx->ex->accept(this);
  }