#include "CodegenVisitor.h"

CodegenVisitor(PropertyManager *pm, std::string moduleName) {
    props = pm;
    context = new LLVMContext();
    module = new Module(moduleName, *context);
    // Use the NoFolder to turn off constant folding
    builder = new IRBuilder<NoFolder>(module->getContext());

    // cached types
    VoidTy = Type::getVoidTy(module->getContext());
    Int32Ty = Type::getInt32Ty(module->getContext());
    Int1Ty = Type::getInt1Ty(module->getContext());
    Int8Ty = Type::getInt8Ty(module->getContext());
    Int32Zero = ConstantInt::get(Int32Ty, 0, true);
    Int32One = ConstantInt::get(Int32Ty, 1, true);
    i8p = Type::getInt8PtrTy(module->getContext());
    Int8PtrPtrTy = i8p->getPointerTo();
}