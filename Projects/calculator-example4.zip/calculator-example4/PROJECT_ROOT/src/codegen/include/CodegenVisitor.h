
// Generated from Calculator.g4 by ANTLR 4.10.1

#pragma once


#include "antlr4-runtime.h"
#include "CalculatorBaseVisitor.h"


/**
 * This class provides an empty implementation of CalculatorVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
using namespace llvm;

class  CodegenVisitor : public CalculatorBaseVisitor {

public:

  //std::any visitProgram(CalculatorParser::ProgramContext *ctx) override;
  //std::any visitBooleanConstant(CalculatorParser::BooleanConstantContext *ctx) override;
  //std::any visitAssignExpression(CalculatorParser::AssignExpressionContext *ctx) override;
  //std::any visitAsgExpr(CalculatorParser::AsgExprContext *ctx) override;
  //std::any visitVConstExpr(CalculatorParser::VConstExprContext *ctx) override;
  //std::any visitIConstExpr(CalculatorParser::IConstExprContext *ctx) override;
  //std::any visitBinaryArithExpr(CalculatorParser::BinaryArithExprContext *ctx) override;
  //std::any visitEqExpr(CalculatorParser::EqExprContext *ctx) override;
  //std::any visitUnaryNotExpr(CalculatorParser::UnaryNotExprContext *ctx) override;
  //std::any visitUnaryEqExpr(CalculatorParser::UnaryEqExprContext *ctx) override;
  //std::any visitParenExpr(CalculatorParser::ParenExprContext *ctx) override;
  //std::any visitBinaryRelExpr(CalculatorParser::BinaryRelExprContext *ctx) override;
  //std::any visitBConstExpr(CalculatorParser::BConstExprContext *ctx) override;

private:
  PropertyManager *props;
  CalcErrorHandler errors;

  LLVMContext *context;
  Module *module;
  IRBuilder<NoFolder> *builder;

  // Cache commonly used types
  Type *VoidTy;
  Type *Int1Ty;
  Type *Int8Ty;
  Type *Int32Ty;
  Type * i8p;
  Type *Int8PtrPtrTy;
  Constant *Int32Zero;
  Constant *Int32One;
  
};

