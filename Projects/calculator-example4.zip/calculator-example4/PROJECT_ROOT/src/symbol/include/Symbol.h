/**
 * @file Symbol.h
 * @author gpollice
 * @brief Definition of a symbol for the Calculator app
 * @version 0.1
 * @date 2022-07-16
 * 
 * You can use this as a template by changing the data items here. The Symbols
 * are stored in the Scope and then associated with parse tree/AST nodes.
 */
#pragma once
#include<string>
#include<sstream>

enum SymType {INT, BOOL, UNDEFINED};

struct Symbol
{
  /* data */
  std::string identifier;
  SymType type;

  Symbol(std::string id,SymType t) {
    identifier = id;
    type = t;
  }

  /**
   * @brief Descriptive string for this symbol.
   * 
   * @return std::string 
   */
  std::string toString() const {
    std::ostringstream description;
    std::string typeName = type == INT ? "INT"
      : type == BOOL ? "BOOL" : "UNDEFINED";
    description << '[' << identifier << ", " << typeName << ']';
    return description.str(); 
  }
};

