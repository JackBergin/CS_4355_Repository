#pragma once
#include "antlr4-runtime.h"
#include "CalculatorBaseVisitor.h"
#include "STManager.h"
#include "PropertyManager.h"
#include "CalcErrorHandler.h"

class SemanticVisitor : CalculatorBaseVisitor {
  public :
    // Pass in the appropriate elements
    SemanticVisitor(STManager* stm, PropertyManager* pm) {
      stmgr = stm;
      bindings = pm;
    }

    std::any visitProgram(CalculatorParser::ProgramContext *ctx);
    std::any visitBooleanConstant(CalculatorParser::BooleanConstantContext *ctx);
    std::any visitIConstExpr(CalculatorParser::IConstExprContext *ctx);
    std::any visitParenExpr(CalculatorParser::ParenExprContext *ctx);
    std::any visitUnaryEqExpr(CalculatorParser::UnaryEqExprContext *ctx);
    std::any visitUnaryNotExpr(CalculatorParser::UnaryNotExprContext *ctx);
    std::any visitBinaryArithExpr(CalculatorParser::BinaryArithExprContext *ctx);
    std::any visitBinaryRelExpr(CalculatorParser::BinaryRelExprContext *ctx);
    std::any visitEqExpr(CalculatorParser::EqExprContext *ctx);
    std::any visitAssignExpression(CalculatorParser::AssignExpressionContext *ctx);
    std::any visitVConstExpr(CalculatorParser::VConstExprContext *ctx);

    std::string getErrors() { return errors.errorList(); }
    STManager* getSTManager() { return stmgr; }
    PropertyManager* getBindings() { return bindings; }
    bool hasErrors() { return errors.hasErrors(); }

  private: 
    STManager* stmgr;
    PropertyManager* bindings; 
    CalcErrorHandler errors;
};
